from django.contrib import admin
from .models import PageCount

# Register your models here.
admin.site.register(PageCount)
